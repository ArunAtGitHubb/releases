package com.example.sntech.util;

public class Category {
    private int image;
    private String title;

    public Category(int image, String title) {
        this.image = image;
        this.title = title;
    }

    public int getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }
}

