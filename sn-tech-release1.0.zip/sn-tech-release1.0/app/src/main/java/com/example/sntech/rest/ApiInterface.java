package com.example.sntech.rest;

import com.example.sntech.response.AboutUsRP;
import com.example.sntech.response.AppRP;
import com.example.sntech.response.BookingHisRP;
import com.example.sntech.response.BookingRoomRP;
import com.example.sntech.response.CheckAvailBookingRoomRP;
import com.example.sntech.response.ContactRP;
import com.example.sntech.response.DataRP;
import com.example.sntech.response.FacilitiesRP;
import com.example.sntech.response.FaqRP;
import com.example.sntech.response.GalleryCatRP;
import com.example.sntech.response.GalleryListRP;
import com.example.sntech.response.GalleryVideoListRP;
import com.example.sntech.response.HomeCatRP;
import com.example.sntech.response.HomeRP;
import com.example.sntech.response.LocationRP;
import com.example.sntech.response.LoginRP;
import com.example.sntech.response.PaymentCheckOutRP;
import com.example.sntech.response.PaypalTokenRP;
import com.example.sntech.response.PrivacyPolicyRP;
import com.example.sntech.response.ProfileRP;
import com.example.sntech.response.RegisterRP;
import com.example.sntech.response.ReviewRP;
import com.example.sntech.response.RoomDetailRP;
import com.example.sntech.response.RoomRP;
import com.example.sntech.response.TermsConditionsRP;
import com.example.sntech.response.UserReviewRP;
import com.example.sntech.response.UserReviewSubmitRP;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;


public interface ApiInterface {

    //get app data
    @POST("api.php")
    @FormUrlEncoded
    Call<AppRP> getAppData(@Field("data") String data);

    //get about us
    @POST("api.php")
    @FormUrlEncoded
    Call<AboutUsRP> getAboutUs(@Field("data") String data);

    //get privacy policy
    @POST("api.php")
    @FormUrlEncoded
    Call<PrivacyPolicyRP> getPrivacyPolicy(@Field("data") String data);

    //get terms condition
    @POST("api.php")
    @FormUrlEncoded
    Call<TermsConditionsRP> getTermsCondition(@Field("data") String data);

    //get faq
    @POST("api.php")
    @FormUrlEncoded
    Call<FaqRP> getFaq(@Field("data") String data);

    //login
    @POST("api.php")
    @FormUrlEncoded
    Call<LoginRP> getLogin(@Field("data") String data);

    //register
    @POST("api.php")
    @FormUrlEncoded
    Call<RegisterRP> getRegister(@Field("data") String data);

    //forgot password
    @POST("api.php")
    @FormUrlEncoded
    Call<DataRP> getForgotPass(@Field("data") String data);

    //login check
    @POST("api.php")
    @FormUrlEncoded
    Call<LoginRP> getLoginDetail(@Field("data") String data);

    //get profile detail
    @POST("api.php")
    @FormUrlEncoded
    Call<ProfileRP> getProfile(@Field("data") String data);

    //edit profile
    @POST("api.php")
    @Multipart
    Call<DataRP> editProfile(@Part("data") RequestBody data, @Part MultipartBody.Part part);

    //update password
    @POST("api.php")
    @FormUrlEncoded
    Call<DataRP> updatePassword(@Field("data") String data);

    //get contact subject
    @POST("api.php")
    @FormUrlEncoded
    Call<ContactRP> getContactSub(@Field("data") String data);

    //submit contact
    @POST("api.php")
    @FormUrlEncoded
    Call<DataRP> submitContact(@Field("data") String data);

    //home
    @POST("api.php")
    @FormUrlEncoded
    Call<HomeRP> getHome(@Field("data") String data);

    //room
    @POST("api.php")
    @FormUrlEncoded
    Call<RoomRP> getRoom(@Field("data") String data);

    //get booking history
    @POST("api.php")
    @FormUrlEncoded
    Call<BookingHisRP> getBookHis(@Field("data") String data);

    //room detail
    @POST("api.php")
    @FormUrlEncoded
    Call<RoomDetailRP> getRoomDetail(@Field("data") String data);

    //review
    @POST("api.php")
    @FormUrlEncoded
    Call<ReviewRP> getReview(@Field("data") String data);

    //user review
    @POST("api.php")
    @FormUrlEncoded
    Call<UserReviewRP> getUserReview(@Field("data") String data);

    //submit review
    @POST("api.php")
    @FormUrlEncoded
    Call<UserReviewSubmitRP> submitUserReview(@Field("data") String data);

    //check avail booking
    @POST("api.php")
    @FormUrlEncoded
    Call<CheckAvailBookingRoomRP> roomBooking(@Field("data") String data);

    @POST("api.php")
    @FormUrlEncoded
    Call<GalleryListRP> getPhoto(@Field("data") String data);

    //booking now
    @POST("api.php")
    @FormUrlEncoded
    Call<BookingRoomRP> roomBooking2(@Field("data") String data);

    //paypal token
    @POST("api.php")
    @FormUrlEncoded
    Call<PaypalTokenRP> paypalToken(@Field("data") String data);

    //paypal check out
    @POST("api.php")
    @FormUrlEncoded
    Call<PaymentCheckOutRP> paypalCheckOut(@Field("data") String data);

    //get gallery
    @POST("api.php")
    @FormUrlEncoded
    Call<GalleryCatRP> getGallery(@Field("data") String data);

    @POST("api.php")
    @FormUrlEncoded
    Call<HomeCatRP> getHomeCat(@Field("data") String data);

    //get gallery detail
    @POST("api.php")
    @FormUrlEncoded
    Call<GalleryListRP> getGalleryList(@Field("data") String data);

    @POST("api.php")
    @FormUrlEncoded
    Call<GalleryVideoListRP> getGalleryVideoList(@Field("data") String data);

    //facilities
    @POST("api.php")
    @FormUrlEncoded
    Call<FacilitiesRP> getFacilities(@Field("data") String data);

    //location
    @POST("api.php")
    @FormUrlEncoded
    Call<LocationRP> getLocation(@Field("data") String data);

}
