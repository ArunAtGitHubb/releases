package com.example.sntech.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.example.sntech.R
import com.example.sntech.activity.Login
import com.example.sntech.activity.QuoteDesign
import com.example.sntech.interfaces.OnItemClickListener
import com.example.sntech.response.GalleryListRP
import com.example.sntech.response.item.GalleryDetailList
import com.example.sntech.rest.ApiClient
import com.example.sntech.rest.ApiInterface
import com.example.sntech.util.API
import com.example.sntech.util.Method
import com.google.android.material.textview.MaterialTextView
import com.google.gson.Gson
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream


class GridPhotoAdapter(
    private val activity: Activity,
    private val context: Context,
    private val imageList: MutableList<GalleryDetailList>?,
    private val onItemClickListener: OnItemClickListener,
    private val userId: String,
) : RecyclerView.Adapter<GridPhotoAdapter.GridViewHolder>(){

    private lateinit var method: Method

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GridViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.grid_item, parent, false)
        method = Method(activity, null)
        return GridViewHolder(view)
    }

    override fun getItemCount(): Int {
        return imageList?.size ?: 0
    }

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onBindViewHolder(holder: GridViewHolder, position: Int) {

        val item = imageList?.get(position)

        holder.imageView.setOnClickListener {
            val builder = Dialog(context)
            builder.requestWindowFeature(Window.FEATURE_NO_TITLE)
            builder.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            builder.setContentView(R.layout.dialog_full_image)

            val expandedImage = builder.findViewById<ImageView>(R.id.expanded_image)
            Glide.with(activity).load(imageList?.get(position)?.wallpaper_image).into(expandedImage)

            builder.show()
        }

        holder.viewBtn.setOnClickListener {
            val builder = Dialog(context)
            builder.requestWindowFeature(Window.FEATURE_NO_TITLE)
            builder.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            builder.setContentView(R.layout.dialog_full_image)

            val expandedImage = builder.findViewById<ImageView>(R.id.expanded_image)
            Glide.with(activity).load(imageList?.get(position)?.wallpaper_image).into(expandedImage)

            builder.show()
        }

        holder.quoteBtn.setOnClickListener {
            val intent = Intent(context, QuoteDesign::class.java)
            intent.putExtra("id", imageList?.get(position)?.id)
            activity.startActivity(intent)
        }

        holder.imageView.setOnClickListener {
            onItemClickListener.onItemClick(position)
        }

        holder.viewBtn.setOnClickListener {
            onItemClickListener.onItemClick(position)
        }

        holder.shareBtn.setOnClickListener {
            Glide.with(context)
                .asBitmap()
                .load(item?.wallpaper_image)
                .into(object : SimpleTarget<Bitmap?>() {
                    override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) { // Save the bitmap locally
                        val values = ContentValues()
                        values.put(MediaStore.Images.Media.DISPLAY_NAME, "${item?.title}.jpg")
                        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        val resolver: ContentResolver = context.contentResolver
                        val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)

                        val outputStream: OutputStream?
                        try {
                            outputStream = resolver.openOutputStream(imageUri!!)
                            resource.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                            outputStream!!.close()
                        } catch (e: IOException) {
                            e.printStackTrace()
                        }

                        val shareIntent = Intent(Intent.ACTION_SEND)
                        shareIntent.type = "image/jpeg"
                        shareIntent.putExtra(Intent.EXTRA_STREAM, imageUri)
                        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Sharing a photo")
                        shareIntent.putExtra(Intent.EXTRA_TEXT, "Check out this photo! \n\n" +
                                "\uD83C\uDF1F Features:\n" +
                                "✅ User-friendly interface for effortless navigation and seamless usage.\n" +
                                "✅ Unlock a range of Construction Designs. \n\n" +
                                "\uD83D\uDCE5 Download our app now \n" +
                                "https://play.google.com/store/apps/details?id=com.example.sntech"
                        )
                        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_MEDIA_LOCATION)
                            != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(context, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            != PackageManager.PERMISSION_GRANTED
                        ) {
                            ActivityCompat.requestPermissions(
                                activity,
                                arrayOf(android.Manifest.permission.ACCESS_MEDIA_LOCATION),
                                1
                            )
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            val uri = Uri.fromParts("package", context.packageName, null)
                            intent.data = uri
                            context.startActivity(intent)
                                Toast.makeText(context, "Storage permission is required...", Toast.LENGTH_LONG).show()
                        } else {
                            context.startActivity(Intent.createChooser(shareIntent, "Share photo"), null)
                        }
                    }
                })
        }

//        holder.shareBtn.setOnClickListener {
//            if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.MANAGE_EXTERNAL_STORAGE)
//                != PackageManager.PERMISSION_GRANTED
//            ) {
//                ActivityCompat.requestPermissions(
//                    activity,
//                    arrayOf(android.Manifest.permission.MANAGE_EXTERNAL_STORAGE),
//                    1
//                )
//                Toast.makeText(context, "Make sure to enable Storage Access...", Toast.LENGTH_LONG).show()
//            } else {
//                Glide.with(context)
//                    .asBitmap()
//                    .load(item?.wallpaper_image)
//                    .into(object : SimpleTarget<Bitmap?>() {
//                        override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
//                            // Save the bitmap locally
//                            val photoUri = saveImageLocally(resource, item?.title!!)
//
//                            // Create a share intent
//                            val shareIntent = Intent(Intent.ACTION_SEND)
//                            shareIntent.type = "image/jpeg"
//
//                            // Set the photo URI as the data for the intent
//                            shareIntent.putExtra(Intent.EXTRA_STREAM, photoUri)
//
//                            // Optionally, provide some text as the subject or message of the share intent
//                            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Sharing a photo")
//                            shareIntent.putExtra(Intent.EXTRA_TEXT, "Check out this photo! \n\n" +
//                                    "\uD83C\uDF1F Features:\n" +
//                                    "✅ User-friendly interface for effortless navigation and seamless usage.\n" +
//                                    "✅ Unlock a range of Construction Designs. \n\n" +
//
//                                    "\uD83D\uDCE5 Download our app now \n" +
//                                    "https://play.google.com/store/apps/details?id=com.example.sntech"
//                            )
//
//                            if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
//                                != PackageManager.PERMISSION_GRANTED
//                            ) {
//                                // Storage permission is not granted, request the permission from the user
//                                ActivityCompat.requestPermissions(
//                                    activity,
//                                    arrayOf(android.Manifest.permission.MANAGE_EXTERNAL_STORAGE),
//                                    1
//                                )
//                                Toast.makeText(context, "Storage permission is required...", Toast.LENGTH_LONG).show()
//                                // Return null to indicate that the image saving is not performed
//                            } else {
//                                context.startActivity(Intent.createChooser(shareIntent, "Share photo"), null)
//                            }
//                        }
//                    })
//            }
//        }


        val heartIcon = holder.itemView.findViewById<ImageView>(R.id.favourite)
        heartIcon.setImageResource(if (item?.isFav == true) R.drawable.heart_select else R.drawable.heart_unselect)
        heartIcon.setOnClickListener {
            if (item != null) {
                item.isFav = !item.isFav

                if(method.isLogin) {
                    heartIcon.setImageResource(if (item.isFav) R.drawable.heart_select else R.drawable.heart_unselect)
                    toggleFavourite(item.isFav, userId, item.id)
                } else {
                    val intent = Intent(context, Login::class.java)
                    activity.startActivity(intent)
                }
            }
        }

        imageList?.get(position)?.title?.let { Log.d("gridTitle", it) };

        holder.textView.text = imageList?.get(position)?.title
        holder.textViewId.text = imageList?.get(position)?.photoId ?: "Design Id"

        Glide.with(activity).load(imageList?.get(position)?.wallpaper_image)
            .placeholder(R.drawable.placeholder_portable)
            .into(holder.imageView)
    }

    private fun saveImageLocally(bitmap: Bitmap, fileTitle: String): Uri? {
        // Check if the storage permission is granted

        // Storage permission is granted, proceed with saving the image
        val directory = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "Design")
        if (!directory.exists()) {
            directory.mkdirs()
        }

        val file = File(directory, "$fileTitle.jpeg")
        try {
            val outputStream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
            outputStream.flush()
            outputStream.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }

        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }
    private fun toggleFavourite(isFav: Boolean, userId: String, photoId: String) {
        val jsObj = Gson().toJsonTree(API(activity)) as JsonObject
        jsObj.addProperty("user_id", userId)
        jsObj.addProperty("photo_id", photoId)
        jsObj.addProperty("isFav", if (isFav) 1 else 0)
        jsObj.addProperty("method_name", "user_fav")
        val apiService = ApiClient.client?.create(ApiInterface::class.java)
        val call = apiService?.getGalleryList(API.toBase64(jsObj.toString()))
        call?.enqueue(object : Callback<GalleryListRP?> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(
                call: Call<GalleryListRP?>,
                response: Response<GalleryListRP?>
            ) {
            }

            override fun onFailure(call: Call<GalleryListRP?>, t: Throwable) {
                TODO("Not yet implemented")
            }

        })
    }

    class GridViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        val imageView: ImageView = itemView.findViewById(R.id.grid_image)
        val textView: MaterialTextView = itemView.findViewById(R.id.textView_gallery_adapter_sub_cat)
        val textViewId: MaterialTextView = itemView.findViewById(R.id.textView_photo_id)
        val viewBtn: Button = itemView.findViewById(R.id.view_btn)
        val quoteBtn: Button = itemView.findViewById(R.id.quote_btn)
        val favouriteBtn: ImageView = itemView.findViewById(R.id.favourite)
        val shareBtn: CardView = itemView.findViewById(R.id.share_card)

        init {
            imageView.setOnClickListener(this)
        }

        override fun onClick(view: View?) {
            val position = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                // open dialog here
            }
        }

    }
}


