package com.example.sntech.adapter;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.sntech.fragment.TabFragment1;
import com.example.sntech.fragment.TabFragment2;
import com.example.sntech.fragment.VideoListFragment;

import java.util.ArrayList;
import java.util.List;

public class MyPagerAdapter extends FragmentPagerAdapter {

    private final List<Fragment> fragments = new ArrayList<>();
    private final List<String> fragmentTitles = new ArrayList<>();
    private final String catId;

    public MyPagerAdapter(FragmentManager fragmentManager, String catId) {
        super(fragmentManager);
        this.catId = catId;
//        super(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
    }

    public void addFragment(Fragment fragment, String title) {
        fragments.add(fragment);
        fragmentTitles.add(title);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        Bundle bundle = new Bundle();
        bundle.putString("catId", catId);
        switch (position) {
            case 0:
                TabFragment1 fragment1 = new TabFragment1();
                fragment1.setArguments(bundle);
                return fragment1;
            case 1:
                VideoListFragment fragment2 = new VideoListFragment();
                fragment2.setArguments(bundle);
                return fragment2;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return 2;
    }

//    @Nullable
//    @Override
//    public CharSequence getPageTitle(int position) {
////        return fragmentTitles.get(position);
//    }
}

