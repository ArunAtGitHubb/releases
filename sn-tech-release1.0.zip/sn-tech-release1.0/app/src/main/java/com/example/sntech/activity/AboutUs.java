package com.example.sntech.activity;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.example.sntech.R;
import com.example.sntech.util.API;
import com.example.sntech.util.Method;
import com.example.sntech.response.AboutUsRP;
import com.example.sntech.rest.ApiClient;
import com.example.sntech.rest.ApiInterface;
import com.bumptech.glide.Glide;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.jetbrains.annotations.NotNull;

import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AboutUs extends AppCompatActivity {

    private Method method;
    private ProgressBar progressBar;
    private WebView webView;
    private ImageView imageView;
    private ConstraintLayout conMain, conNoData;
    private MaterialCardView cardViewEmail, cardViewWebsite, cardViewPhone,
            cardViewWhatsapp, cardViewFacebook, cardViewTwitter, cardViewInstagram,
            cardViewYouTube, cardViewTelegram;
    private MaterialTextView textViewAppName, textViewAppVersion,
            textViewAppContact, textViewAppEmail, textViewAppWebsite,
            textViewWhatsapp, textViewFacebook, textViewInstagram,
            textViewTwitter, textViewYouTube, textViewTelegram;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase));
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);

        method = new Method(AboutUs.this);
        method.forceRTLIfSupported();

        MaterialToolbar toolbar = findViewById(R.id.toolbar_about_us);
        toolbar.setTitle(getResources().getString(R.string.contact_us));
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        conMain = findViewById(R.id.con_about_us);
        conNoData = findViewById(R.id.con_noDataFound);
        progressBar = findViewById(R.id.progressBar_about_us);
        imageView = findViewById(R.id.app_logo_about_us);
        webView = findViewById(R.id.webView_about_us);

        cardViewEmail = findViewById(R.id.cardView_email_about);
        cardViewWebsite = findViewById(R.id.cardView_website_about);
        cardViewPhone = findViewById(R.id.cardView_phone_about);
        cardViewWhatsapp = findViewById(R.id.cardView_whatsapp);
        cardViewFacebook = findViewById(R.id.cardView_facebook);
        cardViewTwitter = findViewById(R.id.cardView_twitter);
        cardViewInstagram = findViewById(R.id.cardView_instagram);
        cardViewYouTube = findViewById(R.id.cardView_youtube);
        cardViewTelegram = findViewById(R.id.cardView_telegram);

        textViewAppName = findViewById(R.id.textView_app_name_about_us);
        textViewAppVersion = findViewById(R.id.textView_app_version_about_us);
        textViewAppContact = findViewById(R.id.textView_app_contact_about_us);
        textViewAppEmail = findViewById(R.id.textView_app_email_about_us);
        textViewAppWebsite = findViewById(R.id.textView_app_website_about_us);
        textViewWhatsapp = findViewById(R.id.textView_whatsapp);
        textViewFacebook = findViewById(R.id.textView_facebook);
        textViewInstagram = findViewById(R.id.textView_instagram);
        textViewTwitter = findViewById(R.id.textView_twitter);
        textViewYouTube = findViewById(R.id.textView_youtube);

        conMain.setVisibility(View.GONE);
        conNoData.setVisibility(View.GONE);

        LinearLayout linearLayout = findViewById(R.id.linearLayout_about_us);
        method.showBannerAd(linearLayout);

        if (method.isNetworkAvailable()) {
            aboutUs();
        } else {
            progressBar.setVisibility(View.GONE);
            method.alertBox(getResources().getString(R.string.internet_connection));
        }
    }
    public void aboutUs() {

        progressBar.setVisibility(View.VISIBLE);

        JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API(AboutUs.this));
        jsObj.addProperty("method_name", "app_about");
        ApiInterface apiService = ApiClient.getClient().create(ApiInterface.class);
        Call<AboutUsRP> call = apiService.getAboutUs(API.toBase64(jsObj.toString()));
        call.enqueue(new Callback<AboutUsRP>() {
            @SuppressLint("SetJavaScriptEnabled")
            @Override
            public void onResponse(@NotNull Call<AboutUsRP> call, @NotNull Response<AboutUsRP> response) {
                int statusCode = response.code();
                try {
                    AboutUsRP aboutUsRp = response.body();
                    assert aboutUsRp != null;

                    if (aboutUsRp.getStatus().equals("1")) {
                        textViewAppName.setText(aboutUsRp.getApp_name());

                        Glide.with(AboutUs.this).load(aboutUsRp.getApp_logo())
                                .placeholder(R.drawable.placeholder_landscape)
                                .into(imageView);

                        Log.d("whatsapp", aboutUsRp.getWhatsapp());

                        textViewAppVersion.setText(aboutUsRp.getApp_version());
                        textViewAppContact.setText(aboutUsRp.getApp_contact());
                        textViewAppEmail.setText(aboutUsRp.getApp_email());
                        textViewAppWebsite.setText(aboutUsRp.getApp_website());
                        textViewWhatsapp.setText(""); //aboutUsRp.getWhatsapp());
                        textViewFacebook.setText(""); //aboutUsRp.getFacebook());
                        textViewInstagram.setText(""); //aboutUsRp.getInstagram());
                        textViewYouTube.setText(""); //aboutUsRp.getYoutube());
                        textViewTwitter.setText(""); //aboutUsRp.getTwitter());

                        webView.setBackgroundColor(Color.TRANSPARENT);
                        webView.setFocusableInTouchMode(false);
                        webView.setFocusable(false);
                        webView.getSettings().setDefaultTextEncodingName("UTF-8");
                        webView.getSettings().setJavaScriptEnabled(true);
                        String mimeType = "text/html";
                        String encoding = "utf-8";

                        String text = "<html dir=" + method.isWebViewTextRtl() + "><head>"
                                + "<style type=\"text/css\">@font-face {font-family: MyFont;src: url(\"file:///android_asset/fonts/poppins_medium.ttf\")}body{font-family: MyFont;color: " + method.webViewText() + "line-height:1.6}"
                                + "a {color:" + method.webViewLink() + "text-decoration:none}"
                                + "</style></head>"
                                + "<body>"
                                + aboutUsRp.getApp_description()
                                + "</body></html>";

                        webView.loadDataWithBaseURL(null, text, mimeType, encoding, null);

                        conMain.setVisibility(View.VISIBLE);

                        cardViewEmail.setOnClickListener(v -> {
                            try {
                                Intent emailIntent = new Intent(Intent.ACTION_VIEW);
                                emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{aboutUsRp.getApp_email()});
                                emailIntent.setData(Uri.parse("mailto:?subject="));
                                startActivity(emailIntent);
                            } catch (android.content.ActivityNotFoundException ex) {
                                method.alertBox(getResources().getString(R.string.wrong));
                            }
                        });

                        cardViewWebsite.setOnClickListener(v -> {
                            try {
                                String url = aboutUsRp.getApp_website();
                                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                                    url = "http://" + url;
                                }
                                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                                startActivity(browserIntent);
                            } catch (Exception e) {
                                method.alertBox(getResources().getString(R.string.wrong));
                            }
                        });

                        cardViewWhatsapp.setOnClickListener(v -> {
//                            String phoneNumber = "8973609501";  // Replace with the desired phone number
//
//                            try {
//                                Intent intent = new Intent(Intent.ACTION_SENDTO);
//                                intent.setData(Uri.parse("smsto:" + phoneNumber));
//                                intent.setPackage("com.gbwhatsapp");
//                                startActivity(intent);
//                            } catch (ActivityNotFoundException e) {
//                                // WhatsApp is not installed on the device, handle the error
//                                Toast.makeText(getApplicationContext(), "WhatsApp is not installed.", Toast.LENGTH_SHORT).show();
//                                e.printStackTrace();
//                            }
                            try {
                                String url = aboutUsRp.getWhatsapp();
                                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                                    url = "http://" + url;
                                }
                                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                                startActivity(browserIntent);
                            } catch (Exception e) {
                                method.alertBox(getResources().getString(R.string.wrong));
                            }
                        });

                        cardViewFacebook.setOnClickListener(v -> {
                            try {
                                String url = aboutUsRp.getFacebook();
                                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                                    url = "http://" + url;
                                }
                                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                                startActivity(browserIntent);
                            } catch (Exception e) {
                                method.alertBox(getResources().getString(R.string.wrong));
                            }
                        });

                        cardViewInstagram.setOnClickListener(v -> {
                            try {
                                String url = aboutUsRp.getInstagram();
                                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                                    url = "http://" + url;
                                }
                                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                                startActivity(browserIntent);
                            } catch (Exception e) {
                                method.alertBox(getResources().getString(R.string.wrong));
                            }
                        });

                        cardViewTwitter.setOnClickListener(v -> {
                            try {
                                String url = aboutUsRp.getTwitter();
                                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                                    url = "http://" + url;
                                }
                                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                                startActivity(browserIntent);
                            } catch (Exception e) {
                                method.alertBox(getResources().getString(R.string.wrong));
                            }
                        });

                        cardViewYouTube.setOnClickListener(v -> {
                            try {
                                String url = aboutUsRp.getYoutube();
                                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                                    url = "http://" + url;
                                }
                                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                                startActivity(browserIntent);
                            } catch (Exception e) {
                                method.alertBox(getResources().getString(R.string.wrong));
                            }
                        });

                        cardViewTelegram.setOnClickListener(v -> {
                            try {
                                Intent telegramIntent = new Intent(Intent.ACTION_VIEW);
                                telegramIntent.setData(Uri.parse(aboutUsRp.getTelegram()));
                                telegramIntent.setPackage("org.telegram.messenger");
                                startActivity(telegramIntent);
                            } catch (ActivityNotFoundException exception) {
                                // Telegram is not installed, handle the error or prompt the user to install Telegram
                                Toast.makeText(getApplication(), "Telegram is not installed", Toast.LENGTH_SHORT).show();
                            }

                        });

                        cardViewPhone.setOnClickListener(v -> {
                            try {
                                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                                callIntent.setData(Uri.parse("tel:" + aboutUsRp.getApp_contact()));
                                startActivity(callIntent);
                            } catch (Exception e) {
                                method.alertBox(getResources().getString(R.string.wrong));
                            }
                        });
                    } else {
                        conNoData.setVisibility(View.VISIBLE);
                        method.alertBox(aboutUsRp.getMessage());
                    }
                } catch (Exception e) {
                    Log.d("exception_error", e.toString());
                    method.alertBox(getResources().getString(R.string.failed_try_again));
                }
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onFailure(@NotNull Call<AboutUsRP> call, @NotNull Throwable t) {
                // Log error here since request failed
                Log.e("fail", t.toString());
                conNoData.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);
                method.alertBox(getResources().getString(R.string.failed_try_again));
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
