package com.example.sntech.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.sntech.R
import com.example.sntech.adapter.VideoAdapter
import com.example.sntech.response.item.GalleryDetailVideoList
import com.example.sntech.response.GalleryVideoListRP
import com.example.sntech.rest.ApiClient
import com.example.sntech.rest.ApiInterface
import com.example.sntech.util.API
import com.example.sntech.util.Video
import com.google.gson.Gson
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class VideoListFragment : Fragment() {
    private var isOver = false
    private lateinit var catId: String
    private var paginationIndex = 1
    private lateinit var videoAdapter: VideoAdapter
    private lateinit var progressBar: ProgressBar
    private lateinit var galleryLists: ArrayList<GalleryDetailVideoList>
    private lateinit var recyclerView: RecyclerView
    private lateinit var conNoData: ConstraintLayout
    private lateinit var videos: ArrayList<Video>

    override fun onPause() {
        super.onPause()
        Log.d("fragmentLifeCycle", "onPause")
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if(hidden) {
            Log.d("fragmentLifeCycle", "fragment hidden")
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_video_list, container, false)
        recyclerView = view.findViewById(R.id.video_list)
        progressBar = view.findViewById(R.id.progressBar)
        conNoData = view.findViewById(R.id.con_noDataFound)
        galleryLists = ArrayList()
        videos= arrayListOf()

        if (arguments != null) {
            catId = requireArguments().getString("catId")!!
            Log.d("catId", requireArguments().getString("catId")!!)
        }

        videoAdapter = VideoAdapter(videos, requireContext())

        recyclerView.setHasFixedSize(true)
        val layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        recyclerView.layoutManager = layoutManager

        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                val layoutManager1 = recyclerView.layoutManager as LinearLayoutManager?
                val visibleItemCount = layoutManager1!!.childCount
                val totalItemCount = layoutManager1.itemCount
                val firstVisibleItemPosition = layoutManager1.findFirstVisibleItemPosition()

                if (visibleItemCount + firstVisibleItemPosition >= totalItemCount && firstVisibleItemPosition >= 0) {
//                    callData()
                }
            }
        })


//        recyclerView.addOnScrollListener(object : EndlessRecyclerViewScrollListener(layoutManager) {
//            override fun onLoadMore(page: Int, totalItemsCount: Int) {
////                if (!isOver) {
//                Log.d("videoList", "loadMore")
//                isNewLoad = false
//                    Handler().postDelayed({
//                        paginationIndex++
//                        callData()
//                    }, 1000)
////                } else {
////                    progressBar.visibility = View.GONE
////                }
//            }
//        })

        callData()

        return view
    }

    override fun onStop() {
        super.onStop()
        Log.d("fragmentLifeCycle", "fragment onStop")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.d("fragmentLifeCycle", "fragment onDestroyView")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("fragmentLifeCycle", "fragment onDestroy")
    }

    fun getMyAdapter(): VideoAdapter {
        return videoAdapter
    }

    private fun callData() {
        if (TabFragment1.isInternetConnected(context)) {
            galleryDetail(catId)
        } else {
            Toast.makeText(
                context,
                resources.getString(R.string.internet_connection),
                Toast.LENGTH_LONG
            ).show()
            progressBar.visibility = View.GONE
        }
//        videoAdapter = VideoAdapter(videos)
    }

    private fun galleryDetail(cat_id: String) {
        val jsObj = Gson().toJsonTree(API(activity)) as JsonObject
        jsObj.addProperty("page", paginationIndex)
        jsObj.addProperty("cat_id", cat_id)
        jsObj.addProperty("method_name", "get_catvideo_by_gallery_id")
        val apiService = ApiClient.client?.create(ApiInterface::class.java)
        val call = apiService?.getGalleryVideoList(API.toBase64(jsObj.toString()))
        call?.enqueue(object : Callback<GalleryVideoListRP> {
            override fun onResponse(
                call: Call<GalleryVideoListRP>,
                response: Response<GalleryVideoListRP>
            ) {
                val res = response.body()

                res?.galleryDetailVideoLists?.let { videoList ->
                    if (videoList.isNotEmpty()) {
                        videoList.forEach {
                            Log.d("videoList", it.getVideo())
                            val video = Video(it.getTitle(), it.getVideo(), it.getVideoUrl())
                            videos.add(video)
                        }
                        Log.d("videoList", "videoIds: $videos")
                        initVideoAdapter()

                        conNoData.visibility = View.GONE
                        progressBar.visibility = View.GONE
                    } else {
                        Log.d("videoList", "Video list is empty")
                    }
                } ?: Log.d("videoList", "Response body is null")

            }

            override fun onFailure(call: Call<GalleryVideoListRP>, t: Throwable) {
                Log.d("videoList", "onFailure")
                conNoData.visibility = View.VISIBLE
            }

        })
    }

    private fun initVideoAdapter() {
        isOver = true
        videoAdapter = VideoAdapter(videos, requireContext())

        recyclerView.adapter = videoAdapter
        videoAdapter.notifyDataSetChanged()
    }

//    private fun getVideos(): ArrayList<Video> {
//        val video1 = Video("Title 1", "ScMzIvxBSi4")
//        val video3 = Video("Title 2", "ak0hINihXIM")
//        val video2 = Video("Title 3", "ScMzIvxBSi4")
//        return arrayListOf(video1, video2, video3)
//    }
}
