package com.example.sntech.interfaces

interface OnItemClickListener {
    fun onItemClick(position: Int)
}
