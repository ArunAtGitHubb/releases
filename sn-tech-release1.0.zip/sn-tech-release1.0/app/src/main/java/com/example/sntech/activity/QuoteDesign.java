package com.example.sntech.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.sntech.R;
import com.example.sntech.response.CheckAvailBookingRoomRP;
import com.example.sntech.response.GalleryListRP;
import com.example.sntech.rest.ApiClient;
import com.example.sntech.rest.ApiInterface;
import com.example.sntech.util.API;
import com.example.sntech.util.Method;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;

import org.jetbrains.annotations.NotNull;

import java.io.StringReader;

import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class QuoteDesign extends AppCompatActivity {

    private Method method;
    private MaterialToolbar toolbar;
    private MaterialButton button;
    private InputMethodManager imm;
    private ProgressDialog progressDialog;
    private TextInputEditText editTextName, editTextEmail, editTextPhoneNo, editTextDesc;
    private String designId;

    private MaterialTextView title;
    private ImageView design;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_room);

        method = new Method(QuoteDesign.this);
        method.forceRTLIfSupported();

        designId = getIntent().getStringExtra("id");
        Log.d("designId", designId);
        progressDialog = new ProgressDialog(QuoteDesign.this);

        button = findViewById(R.id.submit);
        editTextName = findViewById(R.id.name);
        editTextEmail = findViewById(R.id.email);
        editTextPhoneNo = findViewById(R.id.phoneNo);
        editTextDesc = findViewById(R.id.description);
        title = findViewById(R.id.design_name);
        design = findViewById(R.id.grid_image);

        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        toolbar = findViewById(R.id.toolbar_book_room);
        toolbar.setTitle(getResources().getString(R.string.contact));
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        button.setOnClickListener(v -> submit());

        if (method.isNetworkAvailable()) {
            getGalleryDetail(designId);
        } else {
            method.alertBox(getResources().getString(R.string.internet_connection));
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private boolean isValidMail(String email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    public void submit() {

        String name = editTextName.getText().toString();
        String email = editTextEmail.getText().toString();
        String phoneNo = editTextPhoneNo.getText().toString();

        if (name.equals("") || name.isEmpty()) {
            editTextName.requestFocus();
            editTextName.setError(getResources().getString(R.string.please_enter_name));
        } else if (!isValidMail(email) || email.isEmpty()) {
            editTextEmail.requestFocus();
            editTextEmail.setError(getResources().getString(R.string.please_enter_email));
        } else if (phoneNo.equals("") || phoneNo.isEmpty()) {
            editTextPhoneNo.requestFocus();
            editTextPhoneNo.setError(getResources().getString(R.string.please_enter_name));
        } else {
            editTextName.clearFocus();
            editTextEmail.clearFocus();
            editTextPhoneNo.clearFocus();
            imm.hideSoftInputFromWindow(editTextName.getWindowToken(), 0);
            imm.hideSoftInputFromWindow(editTextEmail.getWindowToken(), 0);
            imm.hideSoftInputFromWindow(editTextPhoneNo.getWindowToken(), 0);

            if (method.isNetworkAvailable()) {
                checkBooking();
            }
        }
    }

    private void getGalleryDetail(String designId) {
        progressDialog.show();
        progressDialog.setMessage(getResources().getString(R.string.loading));
        progressDialog.setCancelable(false);

        JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API(QuoteDesign.this));
        jsObj.addProperty("id", designId);
        Log.d("designId", designId);
        jsObj.addProperty("method_name", "get_photo");

        JsonReader reader = new JsonReader(new StringReader(jsObj.toString()));
        reader.setLenient(true);

        ApiInterface apiService = ApiClient.getClient().create(ApiInterface.class);
        Call<GalleryListRP> call = apiService.getPhoto(API.toBase64(jsObj.toString()));
        Log.e("data", "" + API.toBase64(jsObj.toString()));
        call.enqueue(new Callback<GalleryListRP>() {
            @Override
            public void onResponse(@NotNull Call<GalleryListRP> call, @NotNull Response<GalleryListRP> response) {
                try {
                    Log.d("dataFound", response.body().getGalleryDetailLists().toString());
                    GalleryListRP photoDetails = response.body();

                    title.setText(photoDetails.getGalleryDetailLists().get(0).getTitle());
                    Glide.with(getApplication())
                            .load(photoDetails.getGalleryDetailLists().get(0).getWallpaper_image())
                            .placeholder(R.drawable.placeholder_portable)
                            .into(design);
                } catch (Exception e) {
                    Log.d("exception_error", e.toString());
                    method.alertBox(getResources().getString(R.string.failed_try_again));
                }

                progressDialog.dismiss();
            }

            @Override
            public void onFailure(@NotNull Call<GalleryListRP> call, @NotNull Throwable t) {
                // Log error here since request failed
                Log.e("fail", t.toString());
                Log.e("fail", call.toString());
                progressDialog.dismiss();
                method.alertBox(getResources().getString(R.string.failed_try_again));
            }
        });
    }

    private void checkBooking() {

        progressDialog.show();
        progressDialog.setMessage(getResources().getString(R.string.loading));
        progressDialog.setCancelable(false);

        JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API(QuoteDesign.this));

        Log.d("userId", method.userId());
        jsObj.addProperty("id", designId);
        jsObj.addProperty("user_id", method.isLogin() ? method.userId() : null);
        jsObj.addProperty("name", editTextName.getText().toString());
        jsObj.addProperty("email", editTextEmail.getText().toString());
        jsObj.addProperty("phone", editTextPhoneNo.getText().toString());
        jsObj.addProperty("description", editTextDesc.getText().toString());
        jsObj.addProperty("method_name", "get_quote");
        ApiInterface apiService = ApiClient.getClient().create(ApiInterface.class);
        Call<CheckAvailBookingRoomRP> call = apiService.roomBooking(API.toBase64(jsObj.toString()));
        Log.e("dattaa", "" + API.toBase64(jsObj.toString()));
        call.enqueue(new Callback<CheckAvailBookingRoomRP>() {
            @Override
            public void onResponse(@NotNull Call<CheckAvailBookingRoomRP> call, @NotNull Response<CheckAvailBookingRoomRP> response) {
                try {
                    CheckAvailBookingRoomRP bookingRoomRP = response.body();

                    assert bookingRoomRP != null;

                    if (bookingRoomRP.getSuccess().equals("1")) {
//                        if(method.isLogin()) {
//                            Intent intent=new Intent(QuoteDesign.this, QuoteActivity.class);
//                            startActivity(intent);
//                        } else {
                            Intent intent=new Intent(QuoteDesign.this, MainActivity.class);
                            startActivity(intent);
//                        }
                    } else {
                        method.alertBox(bookingRoomRP.getMsg());
                    }

                } catch (Exception e) {
                    Log.d("exception_error", e.toString());
                    method.alertBox(getResources().getString(R.string.failed_try_again));
                }

                progressDialog.dismiss();
            }

            @Override
            public void onFailure(@NotNull Call<CheckAvailBookingRoomRP> call, @NotNull Throwable t) {
                // Log error here since request failed
                Log.e("fail", t.toString());
                progressDialog.dismiss();
                method.alertBox(getResources().getString(R.string.failed_try_again));
            }
        });
    }
}