package com.example.sntech.response.item;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class GalleryDetailVideoList implements Serializable {

    @SerializedName("id")
    private String id;

    @SerializedName("cat_id")
    private String cat_id;

    @SerializedName("title")
    private String title;

    @SerializedName("video")
    private String video;


    public String getId() {
        return id;
    }

    public String getCat_id() {
        return cat_id;
    }

    public String getTitle() {
        return title;
    }

    public String getVideo() {
        return video;
    }

}
