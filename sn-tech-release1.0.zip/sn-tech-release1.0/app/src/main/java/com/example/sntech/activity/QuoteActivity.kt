package com.example.sntech.activity

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.example.sntech.R
import com.example.sntech.activity.MainActivity.toolbar
import com.example.sntech.adapter.GalleryDetailAdapter
import com.example.sntech.adapter.GalleryListAdapter
import com.example.sntech.adapter.QuoteGridPhotoAdapter
import com.example.sntech.interfaces.OnClick
import com.example.sntech.interfaces.OnItemClickListener
import com.example.sntech.response.item.GalleryDetailList
import com.example.sntech.response.GalleryListRP
import com.example.sntech.rest.ApiClient
import com.example.sntech.rest.ApiInterface
import com.example.sntech.util.API
import com.example.sntech.util.EndlessRecyclerViewScrollListener
import com.example.sntech.util.Method
import com.google.android.material.appbar.MaterialToolbar
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class QuoteActivity : AppCompatActivity(), OnItemClickListener {
    private lateinit var method: Method
    private lateinit var onClick: OnClick
    private lateinit var toast: Toast
    private lateinit var progressBar: ProgressBar
    private lateinit var progressCard: CardView
    private lateinit var recycleView: RecyclerView
    private lateinit var viewPager: ViewPager
    private var isOver = false
    private lateinit var conNoData: ConstraintLayout
    private lateinit var catId: String
    private var paginationIndex = 1
    private var totalArraySize = 0
    private var galleryLists: MutableList<GalleryDetailList>? = null
    private var galleryDetailAdapter: GalleryDetailAdapter? = null
    private var galleryListAdapter: GalleryListAdapter? = null

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.quote_activity)

        progressBar = findViewById(R.id.progressBar)
        toast = Toast(this)
        toast.duration = Toast.LENGTH_SHORT
        viewPager = findViewById(R.id.viewPager)
        progressCard = findViewById(R.id.progressCard)
        conNoData = findViewById(R.id.con_noDataFound)
        progressBar.visibility = View.GONE
        progressCard.visibility = View.GONE

        toolbar = findViewById<MaterialToolbar>(R.id.toolbar_quote)
        toolbar.setTitle(resources.getString(R.string.quote))
        setSupportActionBar(toolbar)

        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)

        if (intent != null) {
            catId = intent.getStringExtra("catId").toString()
        }
        onClick = OnClick { position: Int, type: String?, id: String?, title: String? ->
            viewPager.currentItem = position
        }
        method = Method(this, onClick)
        method.forceRTLIfSupported()
        galleryLists = ArrayList()
        val linearLayout = findViewById<LinearLayout>(R.id.ll_gallery_detail)

        val layoutManager = GridLayoutManager(this, 1)

        recycleView = findViewById<RecyclerView>(R.id.recycler_view)
        recycleView.layoutManager = layoutManager

        recycleView.addOnScrollListener(object :
            EndlessRecyclerViewScrollListener(layoutManager) {
            override fun onLoadMore(page: Int, totalItemsCount: Int) {
                if (!isOver) {
                    Handler().postDelayed({
                        paginationIndex++
                        callData()
                    }, 1000)
                } else {
                    Toast.makeText(this@QuoteActivity, "All Images are loaded", Toast.LENGTH_LONG)
                        .show()
                }
            }
        })
        callData()
    }

    override fun onItemClick(position: Int) {
        val item = galleryLists!![position]

        val builder = AlertDialog.Builder(this)
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.dialog_full_image, null)
        val imageView = view.findViewById<ImageView>(R.id.expanded_image)
        Picasso.get().load(item.wallpaper_image).placeholder(R.drawable.placeholder_portable)
            .into(imageView)

        builder.setPositiveButton("Get Quote") { _, _ ->
            val designCatId = item.id
            val intent = Intent(this, QuoteDesign::class.java)
            intent.putExtra("id", designCatId)
            startActivity(intent)
        }

        builder.setNegativeButton("Close") { dialog, _ ->
            dialog.dismiss()
        }

        builder.setView(view)
        builder.show()
    }

    private fun callData() {
        progressBar.visibility = View.VISIBLE
        progressCard.visibility = View.VISIBLE
        if (isInternetConnected(this)) {
            galleryDetail()
        } else {
            Toast.makeText(
                this,
                resources.getString(R.string.internet_connection),
                Toast.LENGTH_LONG
            ).show()
            progressBar.visibility = View.GONE
            progressCard.visibility = View.GONE
        }
    }

    private fun galleryDetail() {
//        if (galleryListAdapter == null || galleryDetailAdapter == null) {
//            galleryLists!!.clear()
//            progressBar.visibility = View.VISIBLE
//        }
        val jsObj = Gson().toJsonTree(API(this)) as JsonObject
        jsObj.addProperty("page", paginationIndex)
        jsObj.addProperty("user_id", method.userId())
        jsObj.addProperty("method_name", "my_quotes")
        val apiService = ApiClient.client?.create(ApiInterface::class.java)
        val call = apiService?.getGalleryList(API.toBase64(jsObj.toString()))
        call?.enqueue(object : Callback<GalleryListRP?> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(
                call: Call<GalleryListRP?>,
                response: Response<GalleryListRP?>
            ) {
                val statusCode = response.code()
                try {
                    val galleryListRP = response.body()!!
                    if (galleryListRP.status == "1") {
                        Log.d("listSize", "${galleryListRP.galleryDetailLists.size}")
                        if (galleryListRP.galleryDetailLists.size == 0) {
                            Log.d("listSize", "isOver")
                            toast.setText("All Images are loaded")
                            toast.cancel()
                            toast.show()
                            if (galleryListAdapter != null) {
                                galleryListAdapter!!.hideHeader()
                                isOver = true
                            }
                            isOver = true
                        } else {
                            Log.d("listSize", "before: $galleryLists")
                            totalArraySize += galleryListRP.galleryDetailLists.size
                            for (i in galleryListRP.galleryDetailLists.indices) {
                                galleryLists!!.add(galleryListRP.galleryDetailLists[i])
                            }

                            Log.d("listSize", "$galleryLists")
                        }
                        if (galleryDetailAdapter == null) {
                            if (galleryLists!!.size != 0) {
                                val adapter = applicationContext?.let { this?.let { it1 ->
                                    QuoteGridPhotoAdapter(
                                        this@QuoteActivity, applicationContext!!, galleryLists, this@QuoteActivity)
                                } }
                                recycleView.adapter = adapter

                                conNoData.visibility = View.GONE
                            } else {
                                conNoData.visibility = View.VISIBLE
                            }
                        } else {
                            galleryDetailAdapter!!.notifyDataSetChanged()
                        }
                    } else {
                        conNoData.visibility = View.VISIBLE
                        method.alertBox(galleryListRP.message)
                    }
                } catch (e: Exception) {
                    Log.d("exception_error", e.toString())
                    method.alertBox(resources.getString(R.string.failed_try_again))
                }
                progressBar.visibility = View.GONE
                progressCard.visibility = View.GONE
            }

            override fun onFailure(call: Call<GalleryListRP?>, t: Throwable) {
                // Log error here since request failed
                Log.e("error_fail", t.toString())
                progressBar.visibility = View.VISIBLE
                progressCard.visibility = View.VISIBLE
                method.alertBox(resources.getString(R.string.failed_try_again))
            }
        })
    }

    companion object {
        fun isInternetConnected(context: Context?): Boolean {
            val connectivityManager =
                context!!.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val networkInfo = connectivityManager.activeNetworkInfo
            return networkInfo != null && networkInfo.isConnected
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    override fun onNavigateUp(): Boolean {
        onBackPressed()
        return super.onNavigateUp()
    }
}