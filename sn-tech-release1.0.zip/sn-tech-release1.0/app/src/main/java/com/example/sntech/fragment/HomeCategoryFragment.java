package com.example.sntech.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.example.sntech.R;
import com.example.sntech.activity.MainActivity;
import com.example.sntech.adapter.HomeCategoryAdapter;
import com.example.sntech.interfaces.OnClick;
import com.example.sntech.response.item.CategoryList;
import com.example.sntech.response.HomeCatRP;
import com.example.sntech.rest.ApiClient;
import com.example.sntech.rest.ApiInterface;
import com.example.sntech.util.API;
import com.example.sntech.util.Constant;
import com.example.sntech.util.EndlessRecyclerViewScrollListener;
import com.example.sntech.util.Method;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeCategoryFragment extends Fragment {

    private Method method;
    private OnClick onClick;
    private ProgressBar progressBar;
    private List<CategoryList> categoryLists;
    private RecyclerView recyclerView;
    private HomeCategoryAdapter homeCategoryAdapter;
    private ConstraintLayout conNoData;
    private Boolean isOver = false;

    private ImageSlider image_slider;
    private int paginationIndex = 1, totalArraySize = 0;
    private ArrayList<SlideModel> banner;


    public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = LayoutInflater.from(getContext()).inflate(R.layout.home_fragment, container, false);

        if (MainActivity.toolbar != null) {
            MainActivity.toolbar.setTitle(getResources().getString(R.string.home));
        }

        categoryLists = new ArrayList<>();

        onClick = (position, type, id, title) -> {
            openFragment(new GalleryFragment(), id);
        };

        method = new Method(getActivity(), onClick);
        banner = new ArrayList<>();

        image_slider = view.findViewById(R.id.image_slider);

        conNoData = view.findViewById(R.id.no_data);
        progressBar = view.findViewById(R.id.progressbar_home);
        recyclerView = view.findViewById(R.id.recyclerView_home_fragment);

        conNoData.setVisibility(View.GONE);

        recyclerView.setHasFixedSize(true);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                if (homeCategoryAdapter != null) {
                    if (homeCategoryAdapter.getItemViewType(position) == 1) {
                        return 1;
                    } else {
                        return 2;
                    }
                }
                return 2;
            }
        });
        recyclerView.setLayoutManager(gridLayoutManager);

        recyclerView.addOnScrollListener(new EndlessRecyclerViewScrollListener(gridLayoutManager) {
            @Override
            public void onLoadMore(int page, int totalItemsCount) {
                if (!isOver) {
                    new Handler().postDelayed(() -> {
                        paginationIndex++;
                        callData();
                    }, 1000);
                } else {
                    homeCategoryAdapter.hideHeader();
                }
            }
        });

        callData();

        return view;
    }

    private void openFragment(Fragment fragment, String id) {
        Bundle bundle = new Bundle();
        bundle.putString("id", id);

        fragment.setArguments(bundle);

        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.frameLayout_main, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }


    private void callData() {
        if (method.isNetworkAvailable()) {
            categories();
        } else {
            progressBar.setVisibility(View.GONE);
            method.alertBox(getResources().getString(R.string.internet_connection));
        }
    }
    private void categories() {

        if (getActivity() != null) {

            if (homeCategoryAdapter == null) {
                categoryLists.clear();
                progressBar.setVisibility(View.VISIBLE);
            }

            JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API(getActivity()));
            jsObj.addProperty("page", paginationIndex);
            jsObj.addProperty("method_name", "get_maincategory");
            ApiInterface apiService = ApiClient.getClient().create(ApiInterface.class);
            Call<HomeCatRP> call = apiService.getHomeCat(API.toBase64(jsObj.toString()));
            call.enqueue(new Callback<HomeCatRP>() {
                @SuppressLint("SetTextI18n")
                @Override
                public void onResponse(@NotNull Call<HomeCatRP> call, @NotNull Response<HomeCatRP> response) {
                    int statusCode = response.code();

                    if (getActivity() != null) {

                        try {

                            HomeCatRP homeCatRP = response.body();

                            assert homeCatRP != null;
                            if (homeCatRP.getStatus().equals("1")) {

                                if (homeCatRP.getCategoryLists().size() == 0) {
                                    if (homeCategoryAdapter != null) {
                                        homeCategoryAdapter.hideHeader();
                                        isOver = true;
                                    }
                                } else {
                                    totalArraySize = totalArraySize + homeCatRP.getCategoryLists().size();
                                    for (int i = 0; i < homeCatRP.getCategoryLists().size(); i++) {
                                        categoryLists.add(homeCatRP.getCategoryLists().get(i));

                                        if (Constant.appRP != null && Constant.nativeAdPos != 0 && Constant.appRP.isNative_ad()) {
                                            int abc = categoryLists.lastIndexOf(null);
                                            if (((categoryLists.size() - (abc + 1)) % Constant.nativeAdPos == 0) && (homeCatRP.getCategoryLists().size() - 1 != i || totalArraySize != 1000)) {
                                                categoryLists.add(null);
                                            }
                                        }
                                    }

                                    for (int i = 0; i < homeCatRP.getBannerLists().size(); i++) {
                                        banner.add(new SlideModel(homeCatRP.getBannerLists().get(i).getBanner_image(), ScaleTypes.FIT));
                                    }

                                    image_slider.setImageList(banner, ScaleTypes.FIT);
                                }

                                if (homeCategoryAdapter == null) {
                                    if (categoryLists.size() != 0) {
                                        homeCategoryAdapter = new HomeCategoryAdapter(getActivity(), "gallery", categoryLists, onClick);
                                        recyclerView.setAdapter(homeCategoryAdapter);
                                    } else {
                                        conNoData.setVisibility(View.VISIBLE);
                                    }
                                } else {
                                    homeCategoryAdapter.notifyDataSetChanged();
                                }
                            } else {
                                conNoData.setVisibility(View.VISIBLE);
                                method.alertBox(homeCatRP.getMessage());
                            }

                        } catch (Exception e) {
                            Log.d("exception_error", e.toString());
                            method.alertBox(getResources().getString(R.string.failed_try_again));
                        }
                    }

                    progressBar.setVisibility(View.GONE);
                }

                @Override
                public void onFailure(@NotNull Call<HomeCatRP> call, @NotNull Throwable t) {
                    // Log error here since request failed
                    Log.e("error_fail", t.toString());
                    progressBar.setVisibility(View.VISIBLE);
                    method.alertBox(getResources().getString(R.string.failed_try_again));
                }
            });
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("tabSelect", "GalleryFragment onDestroy");
    }
}
