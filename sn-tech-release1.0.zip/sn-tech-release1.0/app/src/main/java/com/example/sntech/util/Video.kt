package com.example.sntech.util

import com.google.gson.annotations.SerializedName
import java.io.Serializable

public class Video(title: String, video: String, videoUrl: String) : Serializable {
    @SerializedName("id")
    private lateinit var id: String

    @SerializedName("cat_id")
    private lateinit var cat_id: String

    @SerializedName("title")
    private var title: String = title

    @SerializedName("video")
    private var video: String = video

    @SerializedName("video_url")
    private var video_url: String = videoUrl


    fun getId(): String {
        return id
    }

    fun getCat_id(): String {
        return cat_id
    }

    fun getTitle(): String {
        return title
    }

    fun getVideoUrl(): String {
        return video_url
    }

    fun getVideo(): String {
        return video
    }
}

