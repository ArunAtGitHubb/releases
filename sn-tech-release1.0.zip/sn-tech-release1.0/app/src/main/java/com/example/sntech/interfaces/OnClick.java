package com.example.sntech.interfaces;

public interface OnClick {

    void position(int position, String type, String id, String title);

}
