package com.example.sntech.response.item;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class GalleryDetailList implements Serializable {

    @SerializedName("id")
    private String id;

    @SerializedName("cat_id")
    private String cat_id;

    @SerializedName("wallpaper_image")
    private String wallpaper_image;

    @SerializedName("wallpaper_image_thumb")
    private String wallpaper_image_thumb;

    @SerializedName("title")
    private String title;

    @SerializedName("description")
    private String description;

    @SerializedName("isFav")
    private boolean isFav;

    @SerializedName("photo_id")
    private String photoId;

    public String getPhotoId() {
        return photoId;
    }

    public boolean getIsFav() {return isFav; }

    public void setIsFav(boolean value) { isFav=value; }

    public String getId() {
        return id;
    }

    public String getCat_id() {
        return cat_id;
    }

    public String getWallpaper_image() {
        return wallpaper_image;
    }

    public String getWallpaper_image_thumb() {
        return wallpaper_image_thumb;
    }

    public String getTitle() { return title; }
    public String getDescription() { return description; }
}
