package com.example.sntech.fragment

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import com.example.sntech.R
import com.example.sntech.activity.MainActivity.toolbar
import com.example.sntech.activity.QuoteDesign
import com.example.sntech.adapter.GalleryDetailAdapter
import com.example.sntech.adapter.GalleryListAdapter
import com.example.sntech.adapter.GridPhotoAdapter
import com.example.sntech.interfaces.OnClick
import com.example.sntech.interfaces.OnItemClickListener
import com.example.sntech.response.item.GalleryDetailList
import com.example.sntech.response.GalleryListRP
import com.example.sntech.rest.ApiClient
import com.example.sntech.rest.ApiInterface
import com.example.sntech.util.API
import com.example.sntech.util.EndlessRecyclerViewScrollListener
import com.example.sntech.util.Method
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FavouriteFragment : Fragment(), OnItemClickListener {
    private lateinit var method: Method
    private lateinit var onClick: OnClick
    private lateinit var toast: Toast
    private lateinit var progressBar: ProgressBar
    private lateinit var progressCard: CardView
    private lateinit var recycleView: RecyclerView
    private lateinit var viewPager: ViewPager
    private var isOver = false
    private lateinit var conNoData: ConstraintLayout
    private lateinit var catId: String
    private var paginationIndex = 1
    private var totalArraySize = 0
    private var galleryLists: MutableList<GalleryDetailList>? = null
    private var galleryDetailAdapter: GalleryDetailAdapter? = null
    private var galleryListAdapter: GalleryListAdapter? = null
    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView = inflater.inflate(R.layout.fav_fragment, container, false)
        progressBar = rootView.findViewById(R.id.progressBar)
        toast = Toast(context)
        toast.duration = Toast.LENGTH_SHORT
        viewPager = rootView.findViewById(R.id.viewPager)
        progressCard = rootView.findViewById(R.id.progressCard)
        conNoData = rootView.findViewById(R.id.con_noDataFound)
        Log.d("tabSelect", "tab 1 creating")

        toolbar.title = "Favourites"

        progressBar.visibility = View.GONE
        progressCard.visibility = View.GONE
        if (arguments != null) {
            catId = requireArguments().getString("catId").toString()
            Log.d("catId", requireArguments().getString("catId")!!)
        }
        onClick = OnClick { position: Int, type: String?, id: String?, title: String? ->
            viewPager.currentItem = position
        }
        method = Method(activity, onClick)
        method.forceRTLIfSupported()
        galleryLists = ArrayList()
        val linearLayout = rootView.findViewById<LinearLayout>(R.id.ll_gallery_detail)
        //        method.showBannerAd(linearLayout);

        val layoutManager = GridLayoutManager(context, 1)

        recycleView = rootView.findViewById<RecyclerView>(R.id.recycler_view)
        recycleView.layoutManager = layoutManager

        recycleView.addOnScrollListener(object :
            EndlessRecyclerViewScrollListener(layoutManager) {
            override fun onLoadMore(page: Int, totalItemsCount: Int) {
                if (!isOver) {
                    Handler().postDelayed({
                        paginationIndex++
                        callData()
                    }, 1000)
                } else {
                    Toast.makeText(context, "All Images are loaded", Toast.LENGTH_LONG).show()
                }
            }
        })

        callData()

        return rootView
    }

    override fun onItemClick(position: Int) {
        // Get the clicked item
        val item = galleryLists!![position]

        // Show the image in a dialog
        val builder = AlertDialog.Builder(activity)
        val inflater = LayoutInflater.from(activity)
        val view = inflater.inflate(R.layout.dialog_full_image, null)
        val imageView = view.findViewById<ImageView>(R.id.expanded_image)
        Picasso.get().load(item.wallpaper_image).placeholder(R.drawable.placeholder_portable).into(imageView)

        builder.setPositiveButton("Get Quote") { _, _ ->
            val designCatId = item.id
            Log.d("quoteId", designCatId)
            val intent = Intent(context, QuoteDesign::class.java)
            intent.putExtra("id", designCatId)
            activity?.startActivity(intent)
        }

        builder.setNegativeButton("Close") { dialog, _ ->
            Log.d("getAQuoteNegative", "Get A Quote")
            dialog.dismiss()
        }

        builder.setView(view)
        builder.show()
    }

    private fun callData() {
        progressBar.visibility = View.VISIBLE
        progressCard.visibility = View.VISIBLE
        if (isInternetConnected(context)) {
            galleryDetail()
        } else {
            Toast.makeText(
                context,
                resources.getString(R.string.internet_connection),
                Toast.LENGTH_LONG
            ).show()
            progressBar.visibility = View.GONE
            progressCard.visibility = View.GONE
        }
    }

    var viewPagerPageChangeListener: OnPageChangeListener = object : OnPageChangeListener {
        override fun onPageSelected(position: Int) {}
        override fun onPageScrolled(arg0: Int, arg1: Float, arg2: Int) {}
        override fun onPageScrollStateChanged(arg0: Int) {}
    }

    private fun setCurrentItem(position: Int) {
        viewPager.setCurrentItem(position, false)
    }

    private fun galleryDetail() {
        val jsObj = Gson().toJsonTree(API(activity)) as JsonObject
        jsObj.addProperty("page", paginationIndex)
        Log.d("user_id", if (method.isLogin) method.userId() else "null")
        jsObj.addProperty("user_id", if (method.isLogin) method.userId() else null)
        jsObj.addProperty("method_name", "get_fav")
        val apiService = ApiClient.client?.create(ApiInterface::class.java)
        val call = apiService?.getGalleryList(API.toBase64(jsObj.toString()))
        call?.enqueue(object : Callback<GalleryListRP?> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(
                call: Call<GalleryListRP?>,
                response: Response<GalleryListRP?>
            ) {
                val statusCode = response.code()
                try {
                    val galleryListRP = response.body()!!
                    if (galleryListRP.status == "1") {
                        Log.d("listSize", "${galleryListRP.galleryDetailLists.size}")
                        if (galleryListRP.galleryDetailLists.size == 0) {
                            Log.d("listSize", "isOver")
                            toast.setText("All Items are loaded")
                            toast.cancel()
                            toast.show()
                            if (galleryListAdapter != null) {
                                galleryListAdapter!!.hideHeader()
                                isOver = true
                            }
                            isOver = true
                        } else {
                            Log.d("listSize", "before: $galleryLists")
                            totalArraySize += galleryListRP.galleryDetailLists.size
                            for (i in galleryListRP.galleryDetailLists.indices) {
                                galleryLists!!.add(galleryListRP.galleryDetailLists[i])
                            }

                            Log.d("listSize", "$galleryLists")
                        }
                        if (galleryDetailAdapter == null) {
                            if (galleryLists!!.size != 0) {
                                val adapter = context?.let { activity?.let { it1 ->
                                    GridPhotoAdapter(
                                        it1, context!!, galleryLists, this@FavouriteFragment, method.userId())
                                } }
                                recycleView.adapter = adapter

                                conNoData.visibility = View.GONE
                            } else {
                                conNoData.visibility = View.VISIBLE
                            }
                        } else {
                            galleryDetailAdapter!!.notifyDataSetChanged()
                        }
                    } else {
                        conNoData.visibility = View.VISIBLE
                        method.alertBox(galleryListRP.message)
                    }
                } catch (e: Exception) {
                    Log.d("exception_error", e.toString())
//                    method.alertBox(resources.getString(R.string.failed_try_again))
                }
                progressBar.visibility = View.GONE
                progressCard.visibility = View.GONE
            }

            override fun onFailure(call: Call<GalleryListRP?>, t: Throwable) {
                // Log error here since request failed
                Log.e("error_fail", t.toString())
                progressBar.visibility = View.VISIBLE
                progressCard.visibility = View.VISIBLE
                method.alertBox(resources.getString(R.string.failed_try_again))
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.d("tabSelect", "OnDestroy")
    }

    companion object {
        fun isInternetConnected(context: Context?): Boolean {
            val connectivityManager =
                context!!.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val networkInfo = connectivityManager.activeNetworkInfo
            return networkInfo != null && networkInfo.isConnected
        }
    }
}