package com.example.sntech.response;

import com.example.sntech.util.Video;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class GalleryVideoListRP implements Serializable {

    @SerializedName("SINGLE_HOTEL_APP")
    private ArrayList<Video> galleryDetailVideoLists;

    public ArrayList<Video> getGalleryDetailVideoLists() {
        return galleryDetailVideoLists;
    }
}
