package com.example.sntech.adapter

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.sntech.R
import com.example.sntech.interfaces.OnItemClickListener
import com.example.sntech.response.item.GalleryDetailList
import com.google.android.material.textview.MaterialTextView

class QuoteGridPhotoAdapter(
    private val activity: Activity,
    private val context: Context,
    private val imageList: MutableList<GalleryDetailList>?,

    private val onItemClickListener: OnItemClickListener
) : RecyclerView.Adapter<QuoteGridPhotoAdapter.GridViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GridViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.quote_grid_item, parent, false)
        return GridViewHolder(view)
    }

    override fun getItemCount(): Int {
        return imageList?.size ?: 0
    }

    override fun onBindViewHolder(holder: GridViewHolder, position: Int) {

        val item = imageList?.get(position)

        holder.imageView.setOnClickListener {
            val builder = Dialog(context)
            builder.requestWindowFeature(Window.FEATURE_NO_TITLE)
            builder.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            builder.setContentView(R.layout.dialog_full_image)

            val expandedImage = builder.findViewById<ImageView>(R.id.expanded_image)
            Glide.with(activity).load(imageList?.get(position)?.wallpaper_image).into(expandedImage)

            builder.show()
        }

        holder.imageView.setOnClickListener {
            onItemClickListener.onItemClick(position)
        }

        imageList?.get(position)?.title?.let { Log.d("gridTitle", it) };

        holder.textView.text = imageList?.get(position)?.title
        holder.title.text = imageList?.get(position)?.description

        Glide.with(activity).load(imageList?.get(position)?.wallpaper_image)
            .placeholder(R.drawable.placeholder_portable)
            .into(holder.imageView)
    }

    class GridViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        val imageView: ImageView = itemView.findViewById(R.id.grid_image)
        val textView: MaterialTextView = itemView.findViewById(R.id.textView_gallery_adapter_sub_cat)
        val title: TextView = itemView.findViewById(R.id.description)

        init {
            imageView.setOnClickListener(this)
        }

        override fun onClick(view: View?) {
            val position = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                // open dialog here
            }
        }

    }
}


