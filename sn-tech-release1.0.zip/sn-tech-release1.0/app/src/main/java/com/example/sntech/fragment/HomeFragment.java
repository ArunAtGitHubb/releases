package com.example.sntech.fragment;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.example.sntech.R;
import com.example.sntech.activity.MainActivity;
import com.example.sntech.response.item.ImageSliderAdapter;

import org.jetbrains.annotations.NotNull;


public class HomeFragment extends Fragment {

    private ViewPager viewPager;
    private ConstraintLayout conNoData;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;

    public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        if (MainActivity.toolbar != null) {
            MainActivity.toolbar.setTitle(getResources().getString(R.string.home));
        }
        View view = inflater.inflate(R.layout.home_fragment, container, false);

        // Set up the ViewPager
        viewPager = view.findViewById(R.id.view_pager);
        int[] images = new int[5];
        images[0] = R.drawable.about_us_bg;
        images[1] = R.drawable.about_us_bg;
        images[2] = R.drawable.about_us_bg;
        images[3] = R.drawable.about_us_bg;
        ImageSliderAdapter adapter = new ImageSliderAdapter(getActivity(), images);
        viewPager.setAdapter(adapter);

        conNoData = view.findViewById(R.id.con_noDataFound);
        progressBar = view.findViewById(R.id.progressbar_home);
        recyclerView = view.findViewById(R.id.recyclerView_home_fragment);

//        conNoData.setVisibility(View.GONE);

//        recyclerView.addOnScrollListener(new EndlessRecyclerViewScrollListener(gridLayoutManager) {
//
//        });

        callData();
        return view;
    }

    private void callData() {
        if (isNetworkAvailable()) {
            catGallery();
        } else {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(getContext(), getResources().getString(R.string.internet_connection), Toast.LENGTH_SHORT).show();
        }
    }
    private void catGallery() {

        if (getActivity() != null) {
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
}
