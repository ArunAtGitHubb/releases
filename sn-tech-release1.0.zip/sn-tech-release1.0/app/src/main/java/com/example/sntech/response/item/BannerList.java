package com.example.sntech.response.item;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class BannerList implements Serializable {

    @SerializedName("id")
    private String id;


    @SerializedName("banner_image")
    private String banner_image;

    public String getId() {
        return id;
    }

    public String getBanner_image() {
        return banner_image;
    }
}
