package com.example.sntech.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.example.sntech.fragment.GalleryPhotoFragment
import com.example.sntech.fragment.GalleryVideoFragment

class GalleryDetailsAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT)  {
    private val fragmentList = listOf(GalleryPhotoFragment(), GalleryVideoFragment())

    override fun getItem(position: Int): Fragment {
        // Return a new instance of the appropriate fragment for this position
        return when (position) {
            0 -> GalleryPhotoFragment()
            1 -> GalleryVideoFragment()
            else -> GalleryPhotoFragment()
        }
    }

    override fun getCount(): Int {
        return fragmentList.size
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return when (position) {
            0 -> "Photos"
            1 -> "Videos"
            else -> null
        }
    }
}