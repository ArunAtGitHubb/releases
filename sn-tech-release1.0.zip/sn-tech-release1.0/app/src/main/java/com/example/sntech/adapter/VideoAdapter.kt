package com.example.sntech.adapter

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.sntech.R
import com.example.sntech.util.Video
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerCallback
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView


class VideoAdapter(val videos: ArrayList<Video>, private val context: Context,) : RecyclerView.Adapter<VideoAdapter.VideoViewHolder>() {
    lateinit var youtubeVideo: YouTubePlayerView
    private var currentVideoPlayer: YouTubePlayer? = null
    private var isVideoPlaying: Boolean = false

    class VideoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var shareBtn: CardView = itemView.findViewById(R.id.share_card)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_video, parent, false)
        youtubeVideo = view.findViewById(R.id.videoView)

        return VideoViewHolder(view)
    }

    override fun onBindViewHolder(holder: VideoViewHolder, position: Int) {
        val video = videos[position]
        Log.d("fragmentLifeCycle", "onBindViewHolder")

        holder.shareBtn.setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "text/plain"
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Sharing a Video")
            shareIntent.putExtra(
                Intent.EXTRA_TEXT, "Check out this Youtube video! \n" +
                        video.getVideoUrl() + "\n\n" +
                        "\uD83C\uDF1F Features:\n" +
                        "✅ User-friendly interface for effortless navigation and seamless usage.\n" +
                        "✅ Unlock a range of Construction Designs. \n\n" +

                        "\uD83D\uDCE5 Download our app now \n" +
                        "https://play.google.com/store/apps/details?id=com.example.sntech"
            )
                context.startActivity(Intent.createChooser(shareIntent, "Share Video"), null)
        }

        youtubeVideo.addYouTubePlayerListener(object : AbstractYouTubePlayerListener() {
            override fun onReady(youTubePlayer: YouTubePlayer) {
                Log.d("videoLists", "inside adapter ${video.getVideo()}")
                youTubePlayer.cueVideo(video.getVideo(), 0f)
                currentVideoPlayer = youTubePlayer
            }

            override fun onStateChange(
                youTubePlayer: YouTubePlayer,
                state: PlayerConstants.PlayerState
            ) {
                super.onStateChange(youTubePlayer, state)
                Log.d("adapterLifeCycle", "statusChanged $state")
            }
        })

        if (isVideoPlaying) {
            youtubeVideo.getYouTubePlayerWhenReady(object : YouTubePlayerCallback {
                override fun onYouTubePlayer(youTubePlayer: YouTubePlayer) {
                    youTubePlayer.pause()
                }
            })
            isVideoPlaying = false
        }
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        super.onDetachedFromRecyclerView(recyclerView)
        Log.d("adapterLifeCycle", "onDetached")
    }


    override fun getItemCount() = videos.size

    fun pauseCurrentVideoPlayer() {
        currentVideoPlayer?.pause()
    }

    fun pauseVideo() {
        if (isVideoPlaying) {
            youtubeVideo.getYouTubePlayerWhenReady(object : YouTubePlayerCallback {
                override fun onYouTubePlayer(youTubePlayer: YouTubePlayer) {
                    youTubePlayer.pause()
                }
            })
            isVideoPlaying = false
        }
    }

    // Method to play the video
    fun playVideo() {
        isVideoPlaying = true
    }
}
