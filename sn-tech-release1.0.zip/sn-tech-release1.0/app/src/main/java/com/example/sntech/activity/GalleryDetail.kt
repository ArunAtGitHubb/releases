package com.example.sntech.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.ViewPager
import com.example.sntech.R
import com.example.sntech.adapter.MyPagerAdapter
import com.example.sntech.fragment.GalleryFragment
import com.example.sntech.fragment.HomeCategoryFragment
import com.example.sntech.fragment.VideoListFragment
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener
import com.google.android.material.tabs.TabLayout.TabLayoutOnPageChangeListener
import io.github.inflationx.viewpump.ViewPumpContextWrapper

class GalleryDetail : AppCompatActivity() {
    companion object {
        @JvmStatic
        var COUNT = 0
    }
    private var catId: String? = null
    private lateinit var viewPager: ViewPager
    private lateinit var tabLayout: TabLayout
    var fragment2: VideoListFragment? = null
    lateinit var adapter: MyPagerAdapter
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        Log.d("tabSelect", "clicked")
        return when (item.itemId) {
            R.id.home -> {
                onBackPressed()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("tabSelect", "onCreate in GalleryDetail.kt")
        setContentView(R.layout.activity_gallery_detail)
        val `in` = intent
        catId = `in`.getStringExtra("id")
        val title = `in`.getStringExtra("title")
        val position = `in`.getIntExtra("position", 0)
        val toolbar =
            findViewById<MaterialToolbar>(R.id.toolbar_gallery_detail)

        toolbar.title = title
        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)

        viewPager = findViewById(R.id.viewPager)
        tabLayout = findViewById(R.id.tabLayout)

        tabLayout.addTab(tabLayout.newTab().setText("Photos"))
        tabLayout.addTab(tabLayout.newTab().setText("Videos"))

        val bundle = Bundle()
        bundle.putString("catId", catId)

        adapter = MyPagerAdapter(supportFragmentManager, catId);
        viewPager.adapter = adapter

        viewPager.addOnPageChangeListener(TabLayoutOnPageChangeListener(tabLayout))
        tabLayout.addOnTabSelectedListener(object : OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                viewPager.currentItem = tab.position
                if(viewPager.currentItem == 0) {
                    Log.d("fragmentLifeCycle", "pause the video")
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

    }

    override fun onBackPressed() {
        super.onBackPressed()
        Log.d("tabSelect", "backPressed")
//        backStackRemove()

//        supportFragmentManager.beginTransaction().replace(
//            R.id.frameLayout_main, GalleryFragment(),
//            resources.getString(R.string.home)
//        ).commitAllowingStateLoss()
        //        if (viewPager.getCurrentItem() == 0) {
//            // If the current tab is the first tab, go back to the previous activity
//            super.onBackPressed();
//        } else {
//            // Otherwise, select the previous tab
//            viewPager.setCurrentItem(viewPager.getCurrentItem() - 1);
//        }
    }

    fun backStackRemove() {
        for (i in 0 until supportFragmentManager.backStackEntryCount) {
            supportFragmentManager.popBackStack()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        COUNT = 0
        Log.d("tabSelect", "onDestroy in GalleryDetail.kt")
    }

    override fun onStart() {
        super.onStart()
        Log.d("tabSelect", "onStart in GalleryDetail.kt")
    }

    override fun onResume() {
        super.onResume()
        COUNT++
        if(COUNT >= 2) {
            Log.d("tabSelect", "inside the if block finish()")
            finish()
        }

        Log.d("tabSelect", "onResume in GalleryDetail.kt")
    }

    override fun onStop() {
        super.onStop()
        Log.d("tabSelect", "onStop in GalleryDetail.kt")
    }

    override fun onSupportNavigateUp(): Boolean {
        Log.d("tabSelect", "arraoClicked")
        onBackPressed()
        return true
    }
}